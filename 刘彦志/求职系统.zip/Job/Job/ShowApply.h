#pragma once
#include "MemoryDB.h"
#include "Users.h"

namespace Job {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// ShowApply ժҪ
	/// </summary>
	public ref class ShowApply : public System::Windows::Forms::Form
	{
	public:
		ShowApply(int id, MemoryDB *DB)
		{
			InitializeComponent();
			
			Users *user = DB->getUserById(id,0);

			tbName->Text = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)user->trueName);
			tbTel->Text = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)user->telephone);
			tbAddress->Text = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)user->address);

			if (nullptr != user->info1)
			{
				tbWork->Text = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)user->info1);
			}
			
			if (nullptr != user->info2)
			{
				tbSelf->Text = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)user->info2);
			}
			
			if (nullptr != user->info3)
			{
				tbAward->Text = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)user->info3);
			}


		}

	protected:
		/// <summary>
		/// ������������ʹ�õ���Դ��
		/// </summary>
		~ShowApply()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  tbName;
	private: System::Windows::Forms::TextBox^  tbTel;
	private: System::Windows::Forms::TextBox^  tbAddress;
	private: System::Windows::Forms::TextBox^  tbAward;
	private: System::Windows::Forms::TextBox^  tbSelf;
	private: System::Windows::Forms::TextBox^  tbWork;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;

	private:
		/// <summary>
		/// ����������������
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����֧������ķ��� - ��Ҫ
		/// ʹ�ô���༭���޸Ĵ˷��������ݡ�
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->tbName = (gcnew System::Windows::Forms::TextBox());
			this->tbTel = (gcnew System::Windows::Forms::TextBox());
			this->tbAddress = (gcnew System::Windows::Forms::TextBox());
			this->tbAward = (gcnew System::Windows::Forms::TextBox());
			this->tbSelf = (gcnew System::Windows::Forms::TextBox());
			this->tbWork = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(25, 22);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(71, 12);
			this->label1->TabIndex = 0;
			this->label1->Text = L"��ְ������:";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(242, 22);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(35, 12);
			this->label2->TabIndex = 1;
			this->label2->Text = L"�绰:";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(25, 61);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(35, 12);
			this->label3->TabIndex = 2;
			this->label3->Text = L"��ַ:";
			// 
			// tbName
			// 
			this->tbName->Location = System::Drawing::Point(102, 17);
			this->tbName->Name = L"tbName";
			this->tbName->ReadOnly = true;
			this->tbName->Size = System::Drawing::Size(100, 21);
			this->tbName->TabIndex = 3;
			// 
			// tbTel
			// 
			this->tbTel->Location = System::Drawing::Point(283, 17);
			this->tbTel->Name = L"tbTel";
			this->tbTel->ReadOnly = true;
			this->tbTel->Size = System::Drawing::Size(201, 21);
			this->tbTel->TabIndex = 4;
			// 
			// tbAddress
			// 
			this->tbAddress->Location = System::Drawing::Point(66, 56);
			this->tbAddress->Name = L"tbAddress";
			this->tbAddress->ReadOnly = true;
			this->tbAddress->Size = System::Drawing::Size(418, 21);
			this->tbAddress->TabIndex = 5;
			// 
			// tbAward
			// 
			this->tbAward->Location = System::Drawing::Point(27, 434);
			this->tbAward->MaxLength = 200;
			this->tbAward->Multiline = true;
			this->tbAward->Name = L"tbAward";
			this->tbAward->ReadOnly = true;
			this->tbAward->ScrollBars = System::Windows::Forms::ScrollBars::Both;
			this->tbAward->Size = System::Drawing::Size(457, 136);
			this->tbAward->TabIndex = 11;
			// 
			// tbSelf
			// 
			this->tbSelf->Location = System::Drawing::Point(27, 261);
			this->tbSelf->MaxLength = 200;
			this->tbSelf->Multiline = true;
			this->tbSelf->Name = L"tbSelf";
			this->tbSelf->ReadOnly = true;
			this->tbSelf->ScrollBars = System::Windows::Forms::ScrollBars::Both;
			this->tbSelf->Size = System::Drawing::Size(457, 155);
			this->tbSelf->TabIndex = 10;
			// 
			// tbWork
			// 
			this->tbWork->Location = System::Drawing::Point(27, 104);
			this->tbWork->MaxLength = 200;
			this->tbWork->Multiline = true;
			this->tbWork->Name = L"tbWork";
			this->tbWork->ReadOnly = true;
			this->tbWork->ScrollBars = System::Windows::Forms::ScrollBars::Both;
			this->tbWork->Size = System::Drawing::Size(457, 139);
			this->tbWork->TabIndex = 9;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(25, 419);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(59, 12);
			this->label4->TabIndex = 8;
			this->label4->Text = L"��������:";
			this->label4->Click += gcnew System::EventHandler(this, &ShowApply::label4_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(25, 246);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(65, 12);
			this->label5->TabIndex = 7;
			this->label5->Text = L"����������";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(25, 89);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(65, 12);
			this->label6->TabIndex = 6;
			this->label6->Text = L"���˼�飺";
			// 
			// ShowApply
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 12);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(501, 579);
			this->Controls->Add(this->tbAward);
			this->Controls->Add(this->tbSelf);
			this->Controls->Add(this->tbWork);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->tbAddress);
			this->Controls->Add(this->tbTel);
			this->Controls->Add(this->tbName);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->MaximizeBox = false;
			this->MaximumSize = System::Drawing::Size(517, 618);
			this->MinimizeBox = false;
			this->MinimumSize = System::Drawing::Size(517, 618);
			this->Name = L"ShowApply";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"��ְ������";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label4_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
};
}
