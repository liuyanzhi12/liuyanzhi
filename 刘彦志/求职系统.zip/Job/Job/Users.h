#ifndef USERS_H_H
#define USERS_H_H

//�û�������
class Users
{
public:
	long id;
	char username[50];
	char password[50];
	char trueName[255];
	char address[200];
	char telephone[20];
	char userType[2];
	char info1[500];
	char info2[500];
	char info3[500];
	long score;
};

#endif