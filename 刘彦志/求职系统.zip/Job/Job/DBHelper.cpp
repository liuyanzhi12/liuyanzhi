#include "StdAfx.h"
#include "DBHelper.h"
#include <iostream>

using namespace std;

DBHelper::DBHelper()
{
	
}

bool DBHelper::connect()
{
	bool isConnect = false;

	const char user[] = "root";
	const char pswd[] = "root";
	const char host[] = "localhost";    //or"127.0.0.1"
	const char database[] = "job";        //database
	unsigned int port = 3306;           //server port   

	mysql_init(&myCont);

	isConnect = mysql_real_connect(&myCont,host,user,pswd,database,port,NULL,0);

	mysql_query(&myCont, "SET NAMES 'gb2312'");

	return isConnect;

}


bool DBHelper::executeNonQuery(String^ sql)
{
	char *s = (char*)(void*)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(sql); 

	int code = mysql_query(&myCont,s);

	if(0==code)
	{
		return true;
	}
	char *d = (char *)mysql_error(&myCont);

	cout<<d;
	return false;
}


MYSQL_RES* DBHelper::executeQuery(String^ sql)
{
	char *s = (char*)(void*)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(sql); 

	if(0 ==mysql_query(&myCont,s))
	{		
		return mysql_store_result(&myCont);
	}

	cout<<mysql_error(&myCont);

	return NULL;
}



//���������������ͷ����ݿ�����
DBHelper::~DBHelper()
{
	mysql_close(&myCont);
	
}