#pragma once

#include "MemoryDB.h"
#include "DBHelper.h"
#include "ShowApply.h"
#include "UpdateCompany.h"
#include "FindUser.h"

namespace Job {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Company ժҪ
	/// </summary>
	public ref class Company : public System::Windows::Forms::Form
	{

		MemoryDB *companyDB;

	public:
		Company(MemoryDB *DB)
		{
			InitializeComponent();
			companyDB = DB;
			
			//����������еĵ�ǰ��˾��������Ϣ���ӳ���
			refreshData();

		}

		void refreshData()
		{
			DBHelper *dbHelper = new DBHelper();
			MYSQL_ROW sql_row;

			dbHelper->connect();

			//���ȳ�ʼ���û�
			String^ sql = "select job.Id, job.jobName,userjob.userid,users.truename from job,userjob,users where job.Id = userjob.jobid and   userjob.userid = users.id and job.companyId = '"+System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)companyDB->trueName)+"';";

			MYSQL_RES* res = dbHelper->executeQuery(sql);

			while(sql_row=mysql_fetch_row(res))
			{
				lbApply->Items->Clear();

				String^ jobId = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)sql_row[0]);
				String^ jobName = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)sql_row[1]);
				String^ userId = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)sql_row[2]);
				String^ userName = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)sql_row[3]);

				String^ content = "ְλ���:"+jobId+" ְλ����:"+jobName+" �����˱��:"+userId+" ����������:"+userName;

				lbApply->Items->Add(content);


			}

			if(res!=NULL) mysql_free_result(res);

			delete dbHelper;
		}


	protected:
		/// <summary>
		/// ������������ʹ�õ���Դ��
		/// </summary>
		~Company()
		{
			if (components)
			{
				delete components;
			}
		}

	protected: 



	private: System::Windows::Forms::ListBox^  lbApply;

	private: System::Windows::Forms::Button^  btRefresh;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::PictureBox^  pictureBox2;
	private: System::Windows::Forms::PictureBox^  pictureBox1;


	private:
		/// <summary>
		/// ����������������
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����֧������ķ��� - ��Ҫ
		/// ʹ�ô���༭���޸Ĵ˷��������ݡ�
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Company::typeid));
			this->lbApply = (gcnew System::Windows::Forms::ListBox());
			this->btRefresh = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// lbApply
			// 
			this->lbApply->Font = (gcnew System::Drawing::Font(L"΢���ź�", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(134)));
			this->lbApply->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->lbApply->FormattingEnabled = true;
			this->lbApply->ItemHeight = 25;
			this->lbApply->Location = System::Drawing::Point(8, 54);
			this->lbApply->Name = L"lbApply";
			this->lbApply->Size = System::Drawing::Size(702, 429);
			this->lbApply->TabIndex = 0;
			this->lbApply->MouseDoubleClick += gcnew System::Windows::Forms::MouseEventHandler(this, &Company::lbApply_MouseDoubleClick);
			// 
			// btRefresh
			// 
			this->btRefresh->BackColor = System::Drawing::Color::White;
			this->btRefresh->Location = System::Drawing::Point(302, 12);
			this->btRefresh->Name = L"btRefresh";
			this->btRefresh->Size = System::Drawing::Size(88, 32);
			this->btRefresh->TabIndex = 2;
			this->btRefresh->Text = L"ˢ������";
			this->btRefresh->UseVisualStyleBackColor = false;
			this->btRefresh->Click += gcnew System::EventHandler(this, &Company::btRefresh_Click);
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::White;
			this->button1->Font = (gcnew System::Drawing::Font(L"����", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(134)));
			this->button1->Location = System::Drawing::Point(556, 12);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(154, 32);
			this->button1->TabIndex = 3;
			this->button1->Text = L"���¹�˾����";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &Company::button1_Click);
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::Color::White;
			this->button2->Location = System::Drawing::Point(408, 12);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(90, 32);
			this->button2->TabIndex = 4;
			this->button2->Text = L"�鿴������Ա";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &Company::button2_Click);
			// 
			// pictureBox2
			// 
			this->pictureBox2->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox2.Image")));
			this->pictureBox2->Location = System::Drawing::Point(523, 14);
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->Size = System::Drawing::Size(27, 28);
			this->pictureBox2->TabIndex = 9;
			this->pictureBox2->TabStop = false;
			// 
			// pictureBox1
			// 
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(8, 0);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(279, 48);
			this->pictureBox1->TabIndex = 10;
			this->pictureBox1->TabStop = false;
			// 
			// Company
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 12);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(728, 508);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->pictureBox2);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->btRefresh);
			this->Controls->Add(this->lbApply);
			this->MaximizeBox = false;
			this->MaximumSize = System::Drawing::Size(744, 547);
			this->MinimizeBox = false;
			this->MinimumSize = System::Drawing::Size(744, 547);
			this->Name = L"Company";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"��˾����";
			this->FormClosed += gcnew System::Windows::Forms::FormClosedEventHandler(this, &Company::Company_FormClosed);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void Company_FormClosed(System::Object^  sender, System::Windows::Forms::FormClosedEventArgs^  e) {
				 exit(0);
			 }
private: System::Void btRefresh_Click(System::Object^  sender, System::EventArgs^  e) {
			 this->refreshData();
		 }
private: System::Void lbApply_MouseDoubleClick(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
			 String^ selectText = lbApply->Items[lbApply->SelectedIndex]->ToString();

			 int startIndex = selectText->IndexOf("�����˱��:")+6;
			 int endIndex = selectText->IndexOf("����������:")-1;

			 String^ sid = selectText->Substring(startIndex,endIndex-startIndex);

			 int id = atoi((char*)(void*)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(sid));

			 ShowApply^ sa = gcnew ShowApply(id,companyDB);
			 sa->Show();

		 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {

			 UpdateCompany^ uc = gcnew UpdateCompany(companyDB,true,companyDB->currentUserId);
			 uc->Show();

		 }
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
			 FindUser^ fu = gcnew FindUser(companyDB);
			 fu->Show();
		 }
};
}
