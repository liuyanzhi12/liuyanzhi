#pragma once
#include <stdlib.h>
#include "MemoryDB.h"
#include "JobDetails.h"
#include "UserJob.h"
#include "UpdateInfo.h"

namespace Job {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// ShowJob ժҪ
	/// </summary>
	public ref class ShowJob : public System::Windows::Forms::Form
	{



	public:
		MemoryDB* jobDB;

		ShowJob(MemoryDB* DB)
		{
			InitializeComponent();
			
			jobDB = DB;
		}

	protected:
		/// <summary>
		/// ������������ʹ�õ���Դ��
		/// </summary>
		~ShowJob()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TabControl^  tabControl1;
	private: System::Windows::Forms::TabPage^  tpMyJob;
	protected: 

	private: System::Windows::Forms::TabPage^  tabPage2;


	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TextBox^  tbKeyWord;
	private: System::Windows::Forms::Button^  btQuery;
	private: System::Windows::Forms::ListBox^  lbAllJob;
	private: System::Windows::Forms::ListBox^  lbMyJob;
	private: System::Windows::Forms::Button^  btUpdate;
	private: System::Windows::Forms::Button^  btAsc;
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	private: System::Windows::Forms::PictureBox^  pictureBox2;


	private:
		/// <summary>
		/// ����������������
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����֧������ķ��� - ��Ҫ
		/// ʹ�ô���༭���޸Ĵ˷��������ݡ�
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(ShowJob::typeid));
			this->tabControl1 = (gcnew System::Windows::Forms::TabControl());
			this->tpMyJob = (gcnew System::Windows::Forms::TabPage());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->btAsc = (gcnew System::Windows::Forms::Button());
			this->btUpdate = (gcnew System::Windows::Forms::Button());
			this->lbAllJob = (gcnew System::Windows::Forms::ListBox());
			this->btQuery = (gcnew System::Windows::Forms::Button());
			this->tbKeyWord = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->tabPage2 = (gcnew System::Windows::Forms::TabPage());
			this->lbMyJob = (gcnew System::Windows::Forms::ListBox());
			this->tabControl1->SuspendLayout();
			this->tpMyJob->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->tabPage2->SuspendLayout();
			this->SuspendLayout();
			// 
			// tabControl1
			// 
			this->tabControl1->Controls->Add(this->tpMyJob);
			this->tabControl1->Controls->Add(this->tabPage2);
			this->tabControl1->Location = System::Drawing::Point(12, 12);
			this->tabControl1->Name = L"tabControl1";
			this->tabControl1->SelectedIndex = 0;
			this->tabControl1->Size = System::Drawing::Size(768, 489);
			this->tabControl1->TabIndex = 0;
			this->tabControl1->SelectedIndexChanged += gcnew System::EventHandler(this, &ShowJob::tabControl1_SelectedIndexChanged);
			// 
			// tpMyJob
			// 
			this->tpMyJob->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"tpMyJob.BackgroundImage")));
			this->tpMyJob->Controls->Add(this->pictureBox2);
			this->tpMyJob->Controls->Add(this->pictureBox1);
			this->tpMyJob->Controls->Add(this->btAsc);
			this->tpMyJob->Controls->Add(this->btUpdate);
			this->tpMyJob->Controls->Add(this->lbAllJob);
			this->tpMyJob->Controls->Add(this->btQuery);
			this->tpMyJob->Controls->Add(this->tbKeyWord);
			this->tpMyJob->Controls->Add(this->label1);
			this->tpMyJob->Location = System::Drawing::Point(4, 22);
			this->tpMyJob->Name = L"tpMyJob";
			this->tpMyJob->Padding = System::Windows::Forms::Padding(3);
			this->tpMyJob->Size = System::Drawing::Size(760, 463);
			this->tpMyJob->TabIndex = 0;
			this->tpMyJob->Text = L"ȫ��ְλ";
			this->tpMyJob->UseVisualStyleBackColor = true;
			// 
			// pictureBox2
			// 
			this->pictureBox2->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox2.Image")));
			this->pictureBox2->Location = System::Drawing::Point(630, 6);
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->Size = System::Drawing::Size(27, 28);
			this->pictureBox2->TabIndex = 8;
			this->pictureBox2->TabStop = false;
			// 
			// pictureBox1
			// 
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(11, 9);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(25, 26);
			this->pictureBox1->TabIndex = 7;
			this->pictureBox1->TabStop = false;
			// 
			// btAsc
			// 
			this->btAsc->Location = System::Drawing::Point(435, 10);
			this->btAsc->Name = L"btAsc";
			this->btAsc->Size = System::Drawing::Size(99, 22);
			this->btAsc->TabIndex = 6;
			this->btAsc->Text = L"�����������ѯ";
			this->btAsc->UseVisualStyleBackColor = true;
			this->btAsc->Click += gcnew System::EventHandler(this, &ShowJob::btAsc_Click);
			// 
			// btUpdate
			// 
			this->btUpdate->Location = System::Drawing::Point(663, 9);
			this->btUpdate->Name = L"btUpdate";
			this->btUpdate->Size = System::Drawing::Size(91, 23);
			this->btUpdate->TabIndex = 5;
			this->btUpdate->Text = L"���¸�������";
			this->btUpdate->UseVisualStyleBackColor = true;
			this->btUpdate->Click += gcnew System::EventHandler(this, &ShowJob::btUpdate_Click);
			// 
			// lbAllJob
			// 
			this->lbAllJob->Font = (gcnew System::Drawing::Font(L"΢���ź�", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(134)));
			this->lbAllJob->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->lbAllJob->FormattingEnabled = true;
			this->lbAllJob->HorizontalScrollbar = true;
			this->lbAllJob->ItemHeight = 25;
			this->lbAllJob->Location = System::Drawing::Point(6, 38);
			this->lbAllJob->Name = L"lbAllJob";
			this->lbAllJob->Size = System::Drawing::Size(758, 429);
			this->lbAllJob->TabIndex = 4;
			this->lbAllJob->SelectedIndexChanged += gcnew System::EventHandler(this, &ShowJob::lbAllJob_SelectedIndexChanged);
			this->lbAllJob->MouseDoubleClick += gcnew System::Windows::Forms::MouseEventHandler(this, &ShowJob::lbAllJob_MouseDoubleClick);
			// 
			// btQuery
			// 
			this->btQuery->Location = System::Drawing::Point(310, 10);
			this->btQuery->Name = L"btQuery";
			this->btQuery->Size = System::Drawing::Size(103, 22);
			this->btQuery->TabIndex = 3;
			this->btQuery->Text = L"�����ʽ����ѯ";
			this->btQuery->UseVisualStyleBackColor = true;
			this->btQuery->Click += gcnew System::EventHandler(this, &ShowJob::btQuery_Click);
			// 
			// tbKeyWord
			// 
			this->tbKeyWord->Location = System::Drawing::Point(119, 13);
			this->tbKeyWord->Name = L"tbKeyWord";
			this->tbKeyWord->Size = System::Drawing::Size(173, 21);
			this->tbKeyWord->TabIndex = 2;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(42, 16);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(71, 12);
			this->label1->TabIndex = 1;
			this->label1->Text = L"ְλ�ؼ���:";
			// 
			// tabPage2
			// 
			this->tabPage2->Controls->Add(this->lbMyJob);
			this->tabPage2->Location = System::Drawing::Point(4, 22);
			this->tabPage2->Name = L"tabPage2";
			this->tabPage2->Padding = System::Windows::Forms::Padding(3);
			this->tabPage2->Size = System::Drawing::Size(760, 463);
			this->tabPage2->TabIndex = 1;
			this->tabPage2->Text = L"�������ְλ";
			this->tabPage2->UseVisualStyleBackColor = true;
			// 
			// lbMyJob
			// 
			this->lbMyJob->Font = (gcnew System::Drawing::Font(L"΢���ź�", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(134)));
			this->lbMyJob->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->lbMyJob->FormattingEnabled = true;
			this->lbMyJob->ItemHeight = 25;
			this->lbMyJob->Location = System::Drawing::Point(3, 3);
			this->lbMyJob->Name = L"lbMyJob";
			this->lbMyJob->Size = System::Drawing::Size(751, 454);
			this->lbMyJob->TabIndex = 0;
			// 
			// ShowJob
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 12);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(792, 512);
			this->Controls->Add(this->tabControl1);
			this->MaximizeBox = false;
			this->MaximumSize = System::Drawing::Size(808, 551);
			this->MinimizeBox = false;
			this->MinimumSize = System::Drawing::Size(808, 551);
			this->Name = L"ShowJob";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"�ҵĹ���";
			this->FormClosed += gcnew System::Windows::Forms::FormClosedEventHandler(this, &ShowJob::ShowJob_FormClosed);
			this->Load += gcnew System::EventHandler(this, &ShowJob::ShowJob_Load);
			this->tabControl1->ResumeLayout(false);
			this->tpMyJob->ResumeLayout(false);
			this->tpMyJob->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->tabPage2->ResumeLayout(false);
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void ShowJob_FormClosed(System::Object^  sender, System::Windows::Forms::FormClosedEventArgs^  e) {
				 exit(0); 

			 }
private: System::Void btQuery_Click(System::Object^  sender, System::EventArgs^  e) 
		 {

			 if (tbKeyWord->Text->Trim() == "")
			 {
				 MessageBox::Show( "������Ҫ���ҵĹؼ���.", "ְλ����ʧ��",
					 MessageBoxButtons::OK, MessageBoxIcon::Exclamation );

				 return;
			 }

			 String^ keyWord = tbKeyWord->Text->Trim();

			 lbAllJob->Items->Clear();

			 jobDB->sortCustomer(0);

			 vector<JobEntry>* jobVec = &jobDB->jobVector;

			 JobEntry* jobItem;

			 vector<JobEntry>::iterator it; 

			 for(it=jobVec->begin();it!=jobVec->end();it++)
			 {
				 jobItem = (JobEntry*)(&*it);
				 
				 String^ desc = gcnew String(jobItem->jobDescription);
				 
				 if (desc->IndexOf(keyWord) < 0)
				 {
					 continue;
				 }

				 char aa[10] = {0};

				 itoa(jobItem->id,aa,10);

				 String^ id = gcnew String(aa);

				 String^ data = "ְλ���:"+id+" ְλ����:"+desc;

				 lbAllJob->Items->Add(data);

			 }


		 }
private: System::Void lbAllJob_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {

			 


		 }
private: System::Void lbAllJob_MouseDoubleClick(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {

			 //���Ȼ�ȡ����ǰѡ�����ֵ
			 String^ selectValue = lbAllJob->Items[lbAllJob->SelectedIndex]->ToString();

			 int startPos = selectValue->IndexOf(":")+1;
			 int endPos = selectValue->IndexOf(" ");


			 String^ id = selectValue->Substring(startPos,endPos-startPos);

			 JobDetails^ det =  gcnew JobDetails(jobDB,0,atoi( (char*)(void*)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(id)));
			 det->Show();

		 }
private: System::Void tabControl1_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) 
		 {
			 if (tabControl1->SelectedIndex == 1)
			 {
				 //��ʼ��������Ĺ���
				 lbMyJob->Items->Clear();

				 vector<UserJob> userJobs = jobDB->getJobsByUserId(jobDB->currentUserId);

				 vector<UserJob>::iterator it;

				 UserJob* userJob;

				 for(it=userJobs.begin();it!=userJobs.end();it++)
				 {
					 userJob = (UserJob*)(&*it);
					 
					 char aa[10] = {0};

					 itoa(userJob->jobId,aa,10);

					 String^ id = gcnew String(aa);

					 String^ data = "ְλ���:"+id+" ְλ����:"+gcnew String(userJob->jobDesc);

					 lbMyJob->Items->Add(data);

				 }

			 }			 
		 }
private: System::Void btUpdate_Click(System::Object^  sender, System::EventArgs^  e) {
			 UpdateInfo^ ui = gcnew UpdateInfo(jobDB);
			 ui->Show();

		 }
private: System::Void btAsc_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
			 if (tbKeyWord->Text->Trim() == "")
			 {
				 MessageBox::Show( "������Ҫ���ҵĹؼ���.", "ְλ����ʧ��",
					 MessageBoxButtons::OK, MessageBoxIcon::Exclamation );

				 return;
			 }

			 String^ keyWord = tbKeyWord->Text->Trim();

			 lbAllJob->Items->Clear();

			 jobDB->sortCustomer(1);

			 vector<JobEntry>* jobVec = &jobDB->jobVector;

			 JobEntry* jobItem;

			 vector<JobEntry>::iterator it; 

			 for(it=jobVec->begin();it!=jobVec->end();it++)
			 {
				 jobItem = (JobEntry*)(&*it);

				 String^ desc = gcnew String(jobItem->jobDescription);

				 if (desc->IndexOf(keyWord) < 0)
				 {
					 continue;
				 }

				 char aa[10] = {0};

				 itoa(jobItem->id,aa,10);

				 String^ id = gcnew String(aa);

				 String^ data = "ְλ���:"+id+" ְλ����:"+desc;

				 lbAllJob->Items->Add(data);

			 }
		 }
private: System::Void ShowJob_Load(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}
