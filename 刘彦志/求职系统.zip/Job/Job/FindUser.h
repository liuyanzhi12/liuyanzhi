#pragma once

#include <stdlib.h>
#include "MemoryDB.h"
#include "ShowApply.h"

namespace Job {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// FindUser ժҪ
	/// </summary>
	public ref class FindUser : public System::Windows::Forms::Form
	{
	public:
		MemoryDB* jobDB;
		FindUser(MemoryDB* DB)
		{
			InitializeComponent();
			
			jobDB = DB;
		}

	protected:
		/// <summary>
		/// ������������ʹ�õ���Դ��
		/// </summary>
		~FindUser()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::ListBox^  lbApp;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TextBox^  tbKeyWord;
	private: System::Windows::Forms::Button^  btSearch;
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	protected: 

	private:
		/// <summary>
		/// ����������������
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����֧������ķ��� - ��Ҫ
		/// ʹ�ô���༭���޸Ĵ˷��������ݡ�
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(FindUser::typeid));
			this->lbApp = (gcnew System::Windows::Forms::ListBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->tbKeyWord = (gcnew System::Windows::Forms::TextBox());
			this->btSearch = (gcnew System::Windows::Forms::Button());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// lbApp
			// 
			this->lbApp->Font = (gcnew System::Drawing::Font(L"����", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(134)));
			this->lbApp->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->lbApp->FormattingEnabled = true;
			this->lbApp->ItemHeight = 16;
			this->lbApp->Location = System::Drawing::Point(12, 35);
			this->lbApp->Name = L"lbApp";
			this->lbApp->Size = System::Drawing::Size(546, 436);
			this->lbApp->TabIndex = 0;
			this->lbApp->MouseDoubleClick += gcnew System::Windows::Forms::MouseEventHandler(this, &FindUser::lbApp_MouseDoubleClick);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(12, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(47, 12);
			this->label1->TabIndex = 1;
			this->label1->Text = L"�ؼ���:";
			// 
			// tbKeyWord
			// 
			this->tbKeyWord->Location = System::Drawing::Point(65, 6);
			this->tbKeyWord->Name = L"tbKeyWord";
			this->tbKeyWord->Size = System::Drawing::Size(100, 21);
			this->tbKeyWord->TabIndex = 2;
			// 
			// btSearch
			// 
			this->btSearch->Location = System::Drawing::Point(202, 4);
			this->btSearch->Name = L"btSearch";
			this->btSearch->Size = System::Drawing::Size(75, 23);
			this->btSearch->TabIndex = 3;
			this->btSearch->Text = L"����";
			this->btSearch->UseVisualStyleBackColor = true;
			this->btSearch->Click += gcnew System::EventHandler(this, &FindUser::btSearch_Click);
			// 
			// pictureBox1
			// 
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(171, 3);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(25, 26);
			this->pictureBox1->TabIndex = 4;
			this->pictureBox1->TabStop = false;
			// 
			// FindUser
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 12);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(570, 480);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->btSearch);
			this->Controls->Add(this->tbKeyWord);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->lbApp);
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"FindUser";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"�鿴��ְ��";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btSearch_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 if (tbKeyWord->Text->Trim() == "")
				 {
					 MessageBox::Show( "������Ҫ���ҵĹؼ���.", "ְλ����ʧ��",
						 MessageBoxButtons::OK, MessageBoxIcon::Exclamation );

					 return;
				 }

				 String^ keyWord = tbKeyWord->Text->Trim();

				 lbApp->Items->Clear();

				 vector<Users>* uVec = &jobDB->userVector;

				 Users* userItem;

				 vector<Users>::iterator it; 

				 for(it=uVec->begin();it!=uVec->end();it++)
				 {
					 userItem = (Users*)(&*it);

					 String^ desc = gcnew String(userItem->info1);

					 if (desc->IndexOf(keyWord) < 0)
					 {
						 continue;
					 }

					 char aa[10] = {0};

					 itoa(userItem->id,aa,10);

					 String^ id = gcnew String(aa);

					 String^ data = "��ְ�߱��:"+id+" ��ְ������:"+gcnew String(userItem->trueName);

					 lbApp->Items->Add(data);

				 }

			 }
	private: System::Void lbApp_MouseDoubleClick(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) 
			 {
				 String^ selectText = lbApp->Items[lbApp->SelectedIndex]->ToString();

				 int startIndex = selectText->IndexOf("��ְ�߱��:")+6;
				 int endIndex = selectText->IndexOf("��ְ������:")-1;

				 String^ sid = selectText->Substring(startIndex,endIndex-startIndex);

				 int id = atoi((char*)(void*)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(sid));

				 ShowApply^ sa = gcnew ShowApply(id,jobDB);
				 sa->Show();
			 }
};
}
