#pragma once

#include "Regist.h"
#include "MemoryDB.h"
#include "ShowJob.h"
#include "Company.h"
#include "Admin.h"
extern MemoryDB* myDB;

namespace Job {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Form1 ժҪ
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: �ڴ˴����ӹ��캯������
			//
		}

	protected:
		/// <summary>
		/// ������������ʹ�õ���Դ��
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}

	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  tbName;
	private: System::Windows::Forms::TextBox^  tbPwd;
	private: System::Windows::Forms::Button^  btLogin;
	private: System::Windows::Forms::Button^  btReg;
	private: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	private: System::Windows::Forms::PictureBox^  pictureBox2;
	private: System::Windows::Forms::PictureBox^  pictureBox3;
	private: System::Windows::Forms::PictureBox^  pictureBox4;
	private: System::Windows::Forms::LinkLabel^  linkLabel1;


	protected: 

	protected: 

	private:
		/// <summary>
		/// ����������������
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����֧������ķ��� - ��Ҫ
		/// ʹ�ô���༭���޸Ĵ˷��������ݡ�
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->tbName = (gcnew System::Windows::Forms::TextBox());
			this->tbPwd = (gcnew System::Windows::Forms::TextBox());
			this->btLogin = (gcnew System::Windows::Forms::Button());
			this->btReg = (gcnew System::Windows::Forms::Button());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox3 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox4 = (gcnew System::Windows::Forms::PictureBox());
			this->linkLabel1 = (gcnew System::Windows::Forms::LinkLabel());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox4))->BeginInit();
			this->SuspendLayout();
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::SystemColors::Control;
			this->label2->Location = System::Drawing::Point(305, 259);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(47, 12);
			this->label2->TabIndex = 1;
			this->label2->Text = L"�û���:";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(305, 318);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(47, 12);
			this->label3->TabIndex = 2;
			this->label3->Text = L"��  ��:";
			// 
			// tbName
			// 
			this->tbName->Location = System::Drawing::Point(387, 256);
			this->tbName->Name = L"tbName";
			this->tbName->Size = System::Drawing::Size(188, 21);
			this->tbName->TabIndex = 3;
			// 
			// tbPwd
			// 
			this->tbPwd->Location = System::Drawing::Point(387, 315);
			this->tbPwd->Name = L"tbPwd";
			this->tbPwd->PasswordChar = '*';
			this->tbPwd->Size = System::Drawing::Size(188, 21);
			this->tbPwd->TabIndex = 4;
			// 
			// btLogin
			// 
			this->btLogin->Location = System::Drawing::Point(387, 418);
			this->btLogin->Name = L"btLogin";
			this->btLogin->Size = System::Drawing::Size(75, 23);
			this->btLogin->TabIndex = 5;
			this->btLogin->Text = L"��½";
			this->btLogin->UseVisualStyleBackColor = true;
			this->btLogin->Click += gcnew System::EventHandler(this, &Form1::btLogin_Click);
			// 
			// btReg
			// 
			this->btReg->Location = System::Drawing::Point(500, 418);
			this->btReg->Name = L"btReg";
			this->btReg->Size = System::Drawing::Size(75, 23);
			this->btReg->TabIndex = 6;
			this->btReg->Text = L"ע��";
			this->btReg->UseVisualStyleBackColor = true;
			this->btReg->Click += gcnew System::EventHandler(this, &Form1::btReg_Click);
			// 
			// comboBox1
			// 
			this->comboBox1->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(3) {L"��ְ��", L"��˾", L"��������Ա"});
			this->comboBox1->Location = System::Drawing::Point(387, 369);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(188, 20);
			this->comboBox1->TabIndex = 7;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(305, 372);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(47, 12);
			this->label4->TabIndex = 8;
			this->label4->Text = L"��  ��:";
			// 
			// pictureBox1
			// 
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(163, 58);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(90, 90);
			this->pictureBox1->TabIndex = 9;
			this->pictureBox1->TabStop = false;
			// 
			// pictureBox2
			// 
			this->pictureBox2->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox2.Image")));
			this->pictureBox2->Location = System::Drawing::Point(348, 12);
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->Size = System::Drawing::Size(87, 89);
			this->pictureBox2->TabIndex = 10;
			this->pictureBox2->TabStop = false;
			// 
			// pictureBox3
			// 
			this->pictureBox3->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox3.Image")));
			this->pictureBox3->Location = System::Drawing::Point(504, 71);
			this->pictureBox3->Name = L"pictureBox3";
			this->pictureBox3->Size = System::Drawing::Size(91, 87);
			this->pictureBox3->TabIndex = 11;
			this->pictureBox3->TabStop = false;
			// 
			// pictureBox4
			// 
			this->pictureBox4->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox4.Image")));
			this->pictureBox4->Location = System::Drawing::Point(668, 29);
			this->pictureBox4->Name = L"pictureBox4";
			this->pictureBox4->Size = System::Drawing::Size(87, 91);
			this->pictureBox4->TabIndex = 12;
			this->pictureBox4->TabStop = false;
			// 
			// linkLabel1
			// 
			this->linkLabel1->AutoSize = true;
			this->linkLabel1->LinkColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(128)), 
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->linkLabel1->Location = System::Drawing::Point(642, 496);
			this->linkLabel1->Name = L"linkLabel1";
			this->linkLabel1->Size = System::Drawing::Size(101, 12);
			this->linkLabel1->TabIndex = 13;
			this->linkLabel1->TabStop = true;
			this->linkLabel1->Text = L"���������58ͬ��";
			this->linkLabel1->LinkClicked += gcnew System::Windows::Forms::LinkLabelLinkClickedEventHandler(this, &Form1::linkLabel1_LinkClicked);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 12);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ClientSize = System::Drawing::Size(913, 565);
			this->Controls->Add(this->linkLabel1);
			this->Controls->Add(this->pictureBox4);
			this->Controls->Add(this->pictureBox3);
			this->Controls->Add(this->pictureBox2);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->btReg);
			this->Controls->Add(this->btLogin);
			this->Controls->Add(this->tbPwd);
			this->Controls->Add(this->tbName);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->pictureBox1);
			this->MaximizeBox = false;
			this->Name = L"Form1";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"��ְС���֡���ְ��ְ��";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox4))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btLogin_Click(System::Object^  sender, System::EventArgs^  e) 
	{
		if(this->tbName->Text->Trim() == "")
		{
			MessageBox::Show( "�û�������Ϊ��.", "�û����������",
            MessageBoxButtons::OK, MessageBoxIcon::Exclamation );

			return;
		}

		if(this->tbPwd->Text->Trim() == "")
		{
			MessageBox::Show( "���벻��Ϊ��.", "�����������",
            MessageBoxButtons::OK, MessageBoxIcon::Exclamation );

			return;
		}

		if(this->comboBox1->SelectedIndex < 0)
		{
			MessageBox::Show( "���Ͳ���Ϊ��.", "����ѡ�����",
				MessageBoxButtons::OK, MessageBoxIcon::Exclamation );

			return;
		}

		//У���û�������,�ǵ��ڴ����ݿ�����У���
		char *name = (char*)(void*)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(this->tbName->Text->Trim()); 
		char *pwd = (char*)(void*)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(this->tbPwd->Text->Trim()); 
		
		Users* user = myDB->getUserByNameType(name,this->comboBox1->SelectedIndex);

		if(strcmp(user->password,pwd) == 0)
		{
			//MessageBox::Show( "��Ч�û�.", "�û���֤�ɹ�",
			//	MessageBoxButtons::OK, MessageBoxIcon::Exclamation );

			this->Visible = false;

			myDB->currentUserId = user->id;

			strcpy(myDB->trueName,user->trueName);

			if (this->comboBox1->SelectedIndex == 0)
			{
				ShowJob^ sj = gcnew ShowJob(myDB);
				sj->Show();
			}
			else if (this->comboBox1->SelectedIndex == 1)
			{
				Company^ c = gcnew Company(myDB);
				c->Show();
			}
			else
			{
				Admin^ admin = gcnew Admin(myDB);
				admin->Show();
			}
			


		}
		else
		{
			MessageBox::Show( "�û������������.", "�û���֤ʧ��",
				MessageBoxButtons::OK, MessageBoxIcon::Exclamation );
		}

	}



	//��ע���û�����
private: System::Void btReg_Click(System::Object^  sender, System::EventArgs^  e) 
	{
		Regist^ reg = gcnew Regist();
		reg->Show();
	}
private: System::Void linkLabel1_LinkClicked(System::Object^  sender, System::Windows::Forms::LinkLabelLinkClickedEventArgs^  e) {
			 System::Diagnostics::Process::Start("http://www.58.com");
		 }


};
}

