#pragma once
#include "MemoryDB.h"
#include "Users.h"
#include "DBHelper.h"

namespace Job {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// UpdateInfo ժҪ
	/// </summary>
	public ref class UpdateInfo : public System::Windows::Forms::Form
	{
	public:

		MemoryDB* m_DB;
	private: System::Windows::Forms::Button^  btUpdate;
	public: 

		Users* currentUser;

		UpdateInfo(MemoryDB *DB)
		{
			InitializeComponent();
			m_DB = DB;
			int id = m_DB->currentUserId;

			currentUser = m_DB->getUserById(id,0);
			if(nullptr != currentUser->info1)
			{
				tbWork->Text = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)currentUser->info1);
			}
			
			if(nullptr != currentUser->info2)
			{
				tbSelf->Text = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)currentUser->info2);
			}

			if(nullptr != currentUser->info3)
			{
				tbAward->Text = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)currentUser->info3);
			}

		}

	protected:
		/// <summary>
		/// ������������ʹ�õ���Դ��
		/// </summary>
		~UpdateInfo()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  tbWork;
	private: System::Windows::Forms::TextBox^  tbSelf;
	private: System::Windows::Forms::TextBox^  tbAward;

	private:
		/// <summary>
		/// ����������������
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����֧������ķ��� - ��Ҫ
		/// ʹ�ô���༭���޸Ĵ˷��������ݡ�
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->tbWork = (gcnew System::Windows::Forms::TextBox());
			this->tbSelf = (gcnew System::Windows::Forms::TextBox());
			this->tbAward = (gcnew System::Windows::Forms::TextBox());
			this->btUpdate = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(21, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(65, 12);
			this->label1->TabIndex = 0;
			this->label1->Text = L"���˼�飺";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(21, 166);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(65, 12);
			this->label2->TabIndex = 1;
			this->label2->Text = L"����������";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(21, 339);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(65, 12);
			this->label3->TabIndex = 2;
			this->label3->Text = L"����������";
			// 
			// tbWork
			// 
			this->tbWork->Location = System::Drawing::Point(23, 24);
			this->tbWork->MaxLength = 200;
			this->tbWork->Multiline = true;
			this->tbWork->Name = L"tbWork";
			this->tbWork->ScrollBars = System::Windows::Forms::ScrollBars::Both;
			this->tbWork->Size = System::Drawing::Size(565, 139);
			this->tbWork->TabIndex = 3;
			// 
			// tbSelf
			// 
			this->tbSelf->Location = System::Drawing::Point(23, 181);
			this->tbSelf->MaxLength = 200;
			this->tbSelf->Multiline = true;
			this->tbSelf->Name = L"tbSelf";
			this->tbSelf->ScrollBars = System::Windows::Forms::ScrollBars::Both;
			this->tbSelf->Size = System::Drawing::Size(565, 155);
			this->tbSelf->TabIndex = 4;
			// 
			// tbAward
			// 
			this->tbAward->Location = System::Drawing::Point(23, 354);
			this->tbAward->MaxLength = 200;
			this->tbAward->Multiline = true;
			this->tbAward->Name = L"tbAward";
			this->tbAward->ScrollBars = System::Windows::Forms::ScrollBars::Both;
			this->tbAward->Size = System::Drawing::Size(565, 136);
			this->tbAward->TabIndex = 5;
			// 
			// btUpdate
			// 
			this->btUpdate->Location = System::Drawing::Point(438, 496);
			this->btUpdate->Name = L"btUpdate";
			this->btUpdate->Size = System::Drawing::Size(75, 23);
			this->btUpdate->TabIndex = 6;
			this->btUpdate->Text = L"����";
			this->btUpdate->UseVisualStyleBackColor = true;
			this->btUpdate->Click += gcnew System::EventHandler(this, &UpdateInfo::btUpdate_Click);
			// 
			// UpdateInfo
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 12);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(600, 527);
			this->Controls->Add(this->btUpdate);
			this->Controls->Add(this->tbAward);
			this->Controls->Add(this->tbSelf);
			this->Controls->Add(this->tbWork);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"UpdateInfo";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"���¸�������";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btUpdate_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 //���·�Ϊ������

				 String^ work = tbWork->Text->Replace("'","''");
				 String^ self = tbSelf->Text->Replace("'","''");
				 String^ award = tbAward->Text->Replace("'","''");

				 char aa[10] = {0};
				 itoa(m_DB->currentUserId,aa,10);

				 String^ id = gcnew String(aa);


				 //1�����ڴ����ݿ�
				 char *info1 = (char*)(void*)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(work);
				 char *info2 = (char*)(void*)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(self);
				 char *info3 = (char*)(void*)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(award);

				 memset(currentUser->info1,'\0',500);
				 strcpy(currentUser->info1,info1);

				 memset(currentUser->info2,'\0',500);
				 strcpy(currentUser->info2,info2);
				 
				 memset(currentUser->info3,'\0',500);
				 strcpy(currentUser->info3,info3);



				 //����sql���ݿ�
				 DBHelper* dbHelper = new DBHelper();

				 dbHelper->connect();

				 String^ sql = "update users set info1='"+work+"',info2='"+self+"',info3='"+award+"' where id='"+id+"'";

				 dbHelper->executeNonQuery(sql);

				 delete dbHelper;


				 MessageBox::Show( "���³ɹ�.", "���³ɹ�",
					 MessageBoxButtons::OK, MessageBoxIcon::Exclamation );

			 }
};
}
