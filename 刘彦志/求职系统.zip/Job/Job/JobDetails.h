#pragma once

#include "MemoryDB.h"
#include "DBHelper.h"
#include "UpdateCompany.h"


namespace Job {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// JobDetails ժҪ
	/// </summary>
	public ref class JobDetails : public System::Windows::Forms::Form
	{


	public:
		MemoryDB* jobDB;
		JobEntry* job; 
	private: System::Windows::Forms::Button^  btApply;
	private: System::Windows::Forms::Button^  btCompDetails;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	public: 
		int m_type;


		JobDetails(MemoryDB* DB,int from, int jobId)
		{
			InitializeComponent();
			
			jobDB = DB;
			m_type = from;

			//�������ʼ��������ǩ��ֵ

			job = jobDB->getJobById(jobId);

			char aa[10];
			itoa(jobId,aa,10);

			char bb[10];
			itoa(job->salary,bb,10);

			lbId->Text = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)aa);
			lbCompany->Text = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)job->companyId);
			lbAddress->Text = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)job->workAddress);
			lbSalary->Text = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)bb);

			tbDesc->Text = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)job->jobDescription);
			tbRequire->Text = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)job->jobRequirement);

			if (from != 0)
			{
				btApply->Visible = false;
			}


		}

	protected:
		/// <summary>
		/// ������������ʹ�õ���Դ��
		/// </summary>
		~JobDetails()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::TextBox^  tbDesc;
	private: System::Windows::Forms::TextBox^  tbRequire;
	private: System::Windows::Forms::Label^  lbId;
	private: System::Windows::Forms::Label^  lbCompany;
	private: System::Windows::Forms::Label^  lbAddress;
	private: System::Windows::Forms::Label^  lbSalary;

	private:
		/// <summary>
		/// ����������������
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����֧������ķ��� - ��Ҫ
		/// ʹ�ô���༭���޸Ĵ˷��������ݡ�
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(JobDetails::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->tbDesc = (gcnew System::Windows::Forms::TextBox());
			this->tbRequire = (gcnew System::Windows::Forms::TextBox());
			this->lbId = (gcnew System::Windows::Forms::Label());
			this->lbCompany = (gcnew System::Windows::Forms::Label());
			this->lbAddress = (gcnew System::Windows::Forms::Label());
			this->lbSalary = (gcnew System::Windows::Forms::Label());
			this->btApply = (gcnew System::Windows::Forms::Button());
			this->btCompDetails = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(68, 61);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(59, 12);
			this->label1->TabIndex = 0;
			this->label1->Text = L"ְλ���:";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(235, 61);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(59, 12);
			this->label2->TabIndex = 1;
			this->label2->Text = L"������˾:";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(68, 129);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(59, 12);
			this->label3->TabIndex = 2;
			this->label3->Text = L"�����ص�:";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(68, 172);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(59, 12);
			this->label4->TabIndex = 3;
			this->label4->Text = L"��������:";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(235, 129);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(59, 12);
			this->label5->TabIndex = 4;
			this->label5->Text = L"н��ˮƽ:";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(68, 258);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(53, 12);
			this->label6->TabIndex = 5;
			this->label6->Text = L"����Ҫ��";
			// 
			// tbDesc
			// 
			this->tbDesc->Location = System::Drawing::Point(70, 187);
			this->tbDesc->Multiline = true;
			this->tbDesc->Name = L"tbDesc";
			this->tbDesc->ReadOnly = true;
			this->tbDesc->Size = System::Drawing::Size(455, 55);
			this->tbDesc->TabIndex = 6;
			// 
			// tbRequire
			// 
			this->tbRequire->Location = System::Drawing::Point(70, 273);
			this->tbRequire->Multiline = true;
			this->tbRequire->Name = L"tbRequire";
			this->tbRequire->ReadOnly = true;
			this->tbRequire->Size = System::Drawing::Size(455, 78);
			this->tbRequire->TabIndex = 7;
			// 
			// lbId
			// 
			this->lbId->AutoSize = true;
			this->lbId->Location = System::Drawing::Point(143, 61);
			this->lbId->Name = L"lbId";
			this->lbId->Size = System::Drawing::Size(53, 12);
			this->lbId->TabIndex = 8;
			this->lbId->Text = L"ְλ���";
			// 
			// lbCompany
			// 
			this->lbCompany->AutoSize = true;
			this->lbCompany->Location = System::Drawing::Point(300, 61);
			this->lbCompany->Name = L"lbCompany";
			this->lbCompany->Size = System::Drawing::Size(59, 12);
			this->lbCompany->TabIndex = 9;
			this->lbCompany->Text = L"������˾:";
			// 
			// lbAddress
			// 
			this->lbAddress->AutoSize = true;
			this->lbAddress->Location = System::Drawing::Point(143, 129);
			this->lbAddress->Name = L"lbAddress";
			this->lbAddress->Size = System::Drawing::Size(59, 12);
			this->lbAddress->TabIndex = 10;
			this->lbAddress->Text = L"�����ص�:";
			// 
			// lbSalary
			// 
			this->lbSalary->AutoSize = true;
			this->lbSalary->Location = System::Drawing::Point(300, 129);
			this->lbSalary->Name = L"lbSalary";
			this->lbSalary->Size = System::Drawing::Size(59, 12);
			this->lbSalary->TabIndex = 11;
			this->lbSalary->Text = L"н��ˮƽ:";
			// 
			// btApply
			// 
			this->btApply->Location = System::Drawing::Point(401, 55);
			this->btApply->Name = L"btApply";
			this->btApply->Size = System::Drawing::Size(76, 24);
			this->btApply->TabIndex = 12;
			this->btApply->Text = L"����";
			this->btApply->UseVisualStyleBackColor = true;
			this->btApply->Click += gcnew System::EventHandler(this, &JobDetails::btApply_Click);
			// 
			// btCompDetails
			// 
			this->btCompDetails->Location = System::Drawing::Point(401, 98);
			this->btCompDetails->Name = L"btCompDetails";
			this->btCompDetails->Size = System::Drawing::Size(75, 23);
			this->btCompDetails->TabIndex = 13;
			this->btCompDetails->Text = L"��˾����";
			this->btCompDetails->UseVisualStyleBackColor = true;
			this->btCompDetails->Click += gcnew System::EventHandler(this, &JobDetails::btCompDetails_Click);
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(400, 141);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 14;
			this->button1->Text = L"���Ϊƭ��";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &JobDetails::button1_Click);
			// 
			// pictureBox1
			// 
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(481, 141);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(39, 30);
			this->pictureBox1->TabIndex = 15;
			this->pictureBox1->TabStop = false;
			// 
			// JobDetails
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 12);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(613, 409);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->btCompDetails);
			this->Controls->Add(this->btApply);
			this->Controls->Add(this->lbSalary);
			this->Controls->Add(this->lbAddress);
			this->Controls->Add(this->lbCompany);
			this->Controls->Add(this->lbId);
			this->Controls->Add(this->tbRequire);
			this->Controls->Add(this->tbDesc);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"JobDetails";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"ְλ����";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btApply_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 //�൱�ڱ����ʱ��Ҫ����2���ط�
				 //1������ڴ����ݿ�
				 //2�����mysql���ݿ�

				 //Ҫ�ȼ�鿴�Ƿ��Ѿ����������ְλ
				 vector<UserJob> userJobs = jobDB->getJobsByUserId(jobDB->currentUserId);

				 vector<UserJob>::iterator it;

				 UserJob* userJob;

				 for(it=userJobs.begin();it!=userJobs.end();it++)
				 {
					 userJob = (UserJob*)(&*it);

					 if (userJob->jobId == atol((char*)(void*)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(lbId->Text)))
					 {
						 MessageBox::Show( "���Ѿ������˸�ְλ,�벻Ҫ�ظ�����.", "����ʧ��",
							 MessageBoxButtons::OK, MessageBoxIcon::Exclamation );

						 return;
					 }

				 }




				 UserJob uj = {0};

				 uj.userId = jobDB->currentUserId;
				 uj.jobId = atol((char*)(void*)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(lbId->Text));
				 strcpy(uj.jobDesc,(char*)(void*)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(tbDesc->Text));

				 jobDB->userJobVector.push_back(uj);


				 char aa[10] = {0};

				 itoa(uj.userId,aa,10);

				 String^ id = gcnew String(aa);

				 //�����mysql���ݿ�
				 DBHelper *dbHelper = new DBHelper();
				 dbHelper->connect();
				 String^ sql = "insert into userjob (userid, jobid) values('"+id+"','"+lbId->Text+"')";

				 dbHelper->executeNonQuery(sql);

				 delete dbHelper;

				 MessageBox::Show( "����ɹ�,�����ĵȴ���˾��֪ͨ.", "����ɹ�",
					 MessageBoxButtons::OK, MessageBoxIcon::Exclamation );

			 }
private: System::Void btCompDetails_Click(System::Object^  sender, System::EventArgs^  e) {

			 Users* user = jobDB->getUserByNameType(job->companyId,1);

			 UpdateCompany^ uc = gcnew UpdateCompany(jobDB,false,user->id);
			 uc->Show();

		 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
			 Users* comp = jobDB->getUserByNameType(job->companyId,1);

			 jobDB->incUser(comp->id);

			 //�����mysql���ݿ�
			 DBHelper *dbHelper = new DBHelper();
			 dbHelper->connect();

			 char aa[10] = {0};

			 itoa(comp->id,aa,10);

			 String^ sql = "update users set score=score+1 where id='"+gcnew String(aa)+"'";

			 dbHelper->executeNonQuery(sql);

			 delete dbHelper;

			 MessageBox::Show( "���Ϊƭ�ӳɹ�.", "��ǳɹ�",
				 MessageBoxButtons::OK, MessageBoxIcon::Exclamation );
		 }
};
}
