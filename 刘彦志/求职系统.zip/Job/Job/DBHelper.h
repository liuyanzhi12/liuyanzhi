#ifndef DBHELPER_H_H
#define DBHELPER_H_H


#include <WinSock.h>
#include <mysql.h>

using namespace System;

class DBHelper
{
private:

	MYSQL myCont;
	MYSQL_RES *result;
	MYSQL_ROW sql_row;
	MYSQL_FIELD *fd;
	char column[32][32];

public:
	DBHelper();
	~DBHelper();

	bool connect();

	bool executeNonQuery(String^ sql);

	MYSQL_RES* executeQuery(String^ sql);



};

#endif