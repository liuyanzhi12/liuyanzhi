#pragma once

#include "MemoryDB.h"
#include "Users.h"
#include "DBHelper.h"

namespace Job {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// UpdateCompany ժҪ
	/// </summary>
	public ref class UpdateCompany : public System::Windows::Forms::Form
	{
	public:

		MemoryDB* m_DB;
	private: System::Windows::Forms::Button^  btUpdate;
	public: 
		Users* currentUser;

		UpdateCompany(MemoryDB *DB, bool isModify, int pid)
		{
			InitializeComponent();
			
			m_DB = DB;
			int id = pid;

			currentUser = m_DB->getUserById(id,1);
			if(nullptr != currentUser->info1)
			{
				tbIntro->Text = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)currentUser->info1);
			}

			if(nullptr != currentUser->info2)
			{
				tbJob->Text = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)currentUser->info2);
			}

			if(nullptr != currentUser->info3)
			{
				tbPos->Text = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)currentUser->info3);
			}

			tbIntro->ReadOnly = !isModify;
			tbJob->ReadOnly = !isModify;
			tbPos->ReadOnly = !isModify;

			btUpdate->Visible = isModify;

		}

	protected:
		/// <summary>
		/// ������������ʹ�õ���Դ��
		/// </summary>
		~UpdateCompany()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  tbIntro;
	private: System::Windows::Forms::TextBox^  tbJob;
	private: System::Windows::Forms::TextBox^  tbPos;

	private:
		/// <summary>
		/// ����������������
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����֧������ķ��� - ��Ҫ
		/// ʹ�ô���༭���޸Ĵ˷��������ݡ�
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->tbIntro = (gcnew System::Windows::Forms::TextBox());
			this->tbJob = (gcnew System::Windows::Forms::TextBox());
			this->tbPos = (gcnew System::Windows::Forms::TextBox());
			this->btUpdate = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(12, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(59, 12);
			this->label1->TabIndex = 0;
			this->label1->Text = L"��˾����:";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(12, 134);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(59, 12);
			this->label2->TabIndex = 1;
			this->label2->Text = L"ְλ����:";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(12, 323);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(65, 12);
			this->label3->TabIndex = 2;
			this->label3->Text = L"��ҵ������";
			this->label3->Click += gcnew System::EventHandler(this, &UpdateCompany::label3_Click);
			// 
			// tbIntro
			// 
			this->tbIntro->Location = System::Drawing::Point(14, 24);
			this->tbIntro->Multiline = true;
			this->tbIntro->Name = L"tbIntro";
			this->tbIntro->ScrollBars = System::Windows::Forms::ScrollBars::Both;
			this->tbIntro->Size = System::Drawing::Size(511, 107);
			this->tbIntro->TabIndex = 3;
			// 
			// tbJob
			// 
			this->tbJob->Location = System::Drawing::Point(14, 149);
			this->tbJob->Multiline = true;
			this->tbJob->Name = L"tbJob";
			this->tbJob->ScrollBars = System::Windows::Forms::ScrollBars::Both;
			this->tbJob->Size = System::Drawing::Size(511, 171);
			this->tbJob->TabIndex = 4;
			// 
			// tbPos
			// 
			this->tbPos->Location = System::Drawing::Point(14, 338);
			this->tbPos->Multiline = true;
			this->tbPos->Name = L"tbPos";
			this->tbPos->ScrollBars = System::Windows::Forms::ScrollBars::Both;
			this->tbPos->Size = System::Drawing::Size(511, 146);
			this->tbPos->TabIndex = 5;
			// 
			// btUpdate
			// 
			this->btUpdate->Location = System::Drawing::Point(394, 490);
			this->btUpdate->Name = L"btUpdate";
			this->btUpdate->Size = System::Drawing::Size(75, 23);
			this->btUpdate->TabIndex = 6;
			this->btUpdate->Text = L"����";
			this->btUpdate->UseVisualStyleBackColor = true;
			this->btUpdate->Click += gcnew System::EventHandler(this, &UpdateCompany::btUpdate_Click);
			// 
			// UpdateCompany
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 12);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(537, 521);
			this->Controls->Add(this->btUpdate);
			this->Controls->Add(this->tbPos);
			this->Controls->Add(this->tbJob);
			this->Controls->Add(this->tbIntro);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"UpdateCompany";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"���¹�˾����";
			this->Load += gcnew System::EventHandler(this, &UpdateCompany::UpdateCompany_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void UpdateCompany_Load(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void btUpdate_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
			 //���·�Ϊ������

			 String^ work = tbIntro->Text->Replace("'","''");
			 String^ self = tbJob->Text->Replace("'","''");
			 String^ award = tbPos->Text->Replace("'","''");

			 char aa[10] = {0};
			 itoa(m_DB->currentUserId,aa,10);

			 String^ id = gcnew String(aa);


			 //1�����ڴ����ݿ�
			 char *info1 = (char*)(void*)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(work);
			 char *info2 = (char*)(void*)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(self);
			 char *info3 = (char*)(void*)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(award);

			 memset(currentUser->info1,'\0',500);
			 strcpy(currentUser->info1,info1);

			 memset(currentUser->info2,'\0',500);
			 strcpy(currentUser->info2,info2);

			 memset(currentUser->info3,'\0',500);
			 strcpy(currentUser->info3,info3);



			 //����sql���ݿ�
			 DBHelper* dbHelper = new DBHelper();

			 dbHelper->connect();

			 String^ sql = "update users set info1='"+work+"',info2='"+self+"',info3='"+award+"' where id='"+id+"'";

			 dbHelper->executeNonQuery(sql);

			 delete dbHelper;


			 MessageBox::Show( "���³ɹ�.", "���³ɹ�",
				 MessageBoxButtons::OK, MessageBoxIcon::Exclamation );

		 }
private: System::Void label3_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}
