#pragma once
#include "MemoryDB.h"
#include "Users.h"
#include "DBHelper.h"

namespace Job {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Admin ժҪ
	/// </summary>
	public ref class Admin : public System::Windows::Forms::Form
	{
	public:
		MemoryDB* jobDB;
		Admin(MemoryDB* DB)
		{
			InitializeComponent();
			
			jobDB = DB;
		}

	protected:
		/// <summary>
		/// ������������ʹ�õ���Դ��
		/// </summary>
		~Admin()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::ListBox^  lbApp;

	private: System::Windows::Forms::Button^  btAsc;
	private: System::Windows::Forms::Button^  btDesc;
	private: System::Windows::Forms::Button^  btDel;
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	protected: 

	private:
		/// <summary>
		/// ����������������
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����֧������ķ��� - ��Ҫ
		/// ʹ�ô���༭���޸Ĵ˷��������ݡ�
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Admin::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->lbApp = (gcnew System::Windows::Forms::ListBox());
			this->btAsc = (gcnew System::Windows::Forms::Button());
			this->btDesc = (gcnew System::Windows::Forms::Button());
			this->btDel = (gcnew System::Windows::Forms::Button());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(21, 18);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(77, 12);
			this->label1->TabIndex = 0;
			this->label1->Text = L"ƭ�ӹ�˾�б�";
			// 
			// lbApp
			// 
			this->lbApp->Font = (gcnew System::Drawing::Font(L"����", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(134)));
			this->lbApp->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->lbApp->FormattingEnabled = true;
			this->lbApp->ItemHeight = 16;
			this->lbApp->Location = System::Drawing::Point(23, 42);
			this->lbApp->Name = L"lbApp";
			this->lbApp->Size = System::Drawing::Size(600, 420);
			this->lbApp->TabIndex = 1;
			// 
			// btAsc
			// 
			this->btAsc->Location = System::Drawing::Point(169, 13);
			this->btAsc->Name = L"btAsc";
			this->btAsc->Size = System::Drawing::Size(89, 23);
			this->btAsc->TabIndex = 2;
			this->btAsc->Text = L"���������";
			this->btAsc->UseVisualStyleBackColor = true;
			this->btAsc->Click += gcnew System::EventHandler(this, &Admin::btAsc_Click);
			// 
			// btDesc
			// 
			this->btDesc->Location = System::Drawing::Point(299, 13);
			this->btDesc->Name = L"btDesc";
			this->btDesc->Size = System::Drawing::Size(75, 23);
			this->btDesc->TabIndex = 3;
			this->btDesc->Text = L"���������";
			this->btDesc->UseVisualStyleBackColor = true;
			this->btDesc->Click += gcnew System::EventHandler(this, &Admin::btDesc_Click);
			// 
			// btDel
			// 
			this->btDel->Location = System::Drawing::Point(503, 15);
			this->btDel->Name = L"btDel";
			this->btDel->Size = System::Drawing::Size(75, 21);
			this->btDel->TabIndex = 4;
			this->btDel->Text = L"ɾ��";
			this->btDel->UseVisualStyleBackColor = true;
			this->btDel->Click += gcnew System::EventHandler(this, &Admin::btDel_Click);
			// 
			// pictureBox1
			// 
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(584, 6);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(39, 30);
			this->pictureBox1->TabIndex = 5;
			this->pictureBox1->TabStop = false;
			// 
			// Admin
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 12);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(635, 499);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->btDel);
			this->Controls->Add(this->btDesc);
			this->Controls->Add(this->btAsc);
			this->Controls->Add(this->lbApp);
			this->Controls->Add(this->label1);
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"Admin";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"��������Ա";
			this->FormClosed += gcnew System::Windows::Forms::FormClosedEventHandler(this, &Admin::Admin_FormClosed);
			this->Load += gcnew System::EventHandler(this, &Admin::Admin_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Admin_Load(System::Object^  sender, System::EventArgs^  e) 
			 {
				 jobDB->sortUsers(1);

				 vector<Users>* uVec = &jobDB->compVector;

				 Users* userItem;

				 vector<Users>::iterator it; 

				 for(it=uVec->begin();it!=uVec->end();it++)
				 {
					 userItem = (Users*)(&*it);
					 char aa[10] = {0};

					 itoa(userItem->id,aa,10);

					 String^ id = gcnew String(aa);

					 char bb[10] = {0};
					 itoa(userItem->score,bb,10);

					 String^ score = gcnew String(bb);

					 String^ data = "��˾���:"+id+" ��˾����:"+gcnew String(userItem->trueName)+" ��˾�������:"+score;

					 lbApp->Items->Add(data);

				 }
			 }
private: System::Void btAsc_Click(System::Object^  sender, System::EventArgs^  e) {

			 jobDB->sortUsers(0);

			 vector<Users>* uVec = &jobDB->compVector;

			 Users* userItem;

			 vector<Users>::iterator it; 

			 lbApp->Items->Clear();

			 for(it=uVec->begin();it!=uVec->end();it++)
			 {
				 userItem = (Users*)(&*it);
				 char aa[10] = {0};

				 itoa(userItem->id,aa,10);

				 String^ id = gcnew String(aa);

				 char bb[10] = {0};
				 itoa(userItem->score,bb,10);

				 String^ score = gcnew String(bb);

				 String^ data = "��˾���:"+id+" ��˾����:"+gcnew String(userItem->trueName)+" ��˾�������:"+score;

				 lbApp->Items->Add(data);

			 }

		 }
private: System::Void btDesc_Click(System::Object^  sender, System::EventArgs^  e) {
			 jobDB->sortUsers(1);

			 vector<Users>* uVec = &jobDB->compVector;

			 Users* userItem;

			 vector<Users>::iterator it; 
			 lbApp->Items->Clear();
			 for(it=uVec->begin();it!=uVec->end();it++)
			 {
				 userItem = (Users*)(&*it);
				 char aa[10] = {0};

				 itoa(userItem->id,aa,10);

				 String^ id = gcnew String(aa);

				 char bb[10] = {0};
				 itoa(userItem->score,bb,10);

				 String^ score = gcnew String(bb);

				 String^ data = "��˾���:"+id+" ��˾����:"+gcnew String(userItem->trueName)+" ��˾�������:"+score;

				 lbApp->Items->Add(data);

			 }
		 }
private: System::Void Admin_FormClosed(System::Object^  sender, System::Windows::Forms::FormClosedEventArgs^  e) {
			 exit(0); 
		 }
private: System::Void btDel_Click(System::Object^  sender, System::EventArgs^  e) {

			 if(lbApp->SelectedIndex < 0)
			 {
				MessageBox::Show( "��ѡ��Ҫɾ���Ĺ�˾.", "ɾ��ʧ��",
						 MessageBoxButtons::OK, MessageBoxIcon::Exclamation );

				return;
			 }

			 String^ selectText = lbApp->Items[lbApp->SelectedIndex]->ToString();

			 int startIndex = selectText->IndexOf("��˾���:")+5;
			 int endIndex = selectText->IndexOf("��˾����:")-1;

			 String^ sid = selectText->Substring(startIndex,endIndex-startIndex);

			 int id = atoi((char*)(void*)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(sid));

			 jobDB->removeFromCompVector(id);


			 //�����mysql���ݿ�
			 DBHelper *dbHelper = new DBHelper();
			 dbHelper->connect();

			 String^ sql = "delete from users where id='"+sid+"'";

			 dbHelper->executeNonQuery(sql);

			 delete dbHelper;

			 lbApp->Items->RemoveAt(lbApp->SelectedIndex);

			 MessageBox::Show( "ɾ��ƭ�ӹ�˾�ɹ�.", "��ǳɹ�",
				 MessageBoxButtons::OK, MessageBoxIcon::Exclamation );

		 }
};
}
