#ifndef USERJOB_H_H
#define USERJOB_H_H

//�û�������
class UserJob
{
public:
	long id;
	long userId;
	long jobId;
	char jobDesc[100];

};


#endif