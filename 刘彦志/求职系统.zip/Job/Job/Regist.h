#pragma once

#include "DBHelper.h"

namespace Job {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Regist ժҪ
	/// </summary>
	public ref class Regist : public System::Windows::Forms::Form
	{
	public:
		Regist(void)
		{
			InitializeComponent();
			//
			//TODO: �ڴ˴����ӹ��캯������
			//
		}

	protected:
		/// <summary>
		/// ������������ʹ�õ���Դ��
		/// </summary>
		~Regist()
		{
			if (components)
			{
				delete components;
			}
		}

	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::TextBox^  tbName;
	private: System::Windows::Forms::TextBox^  tbPwd;
	private: System::Windows::Forms::TextBox^  tbTrueName;
	private: System::Windows::Forms::TextBox^  tbAddress;
	private: System::Windows::Forms::TextBox^  tbTel;
	private: System::Windows::Forms::ComboBox^  cbType;

	private: System::Windows::Forms::Button^  btOk;
	private: System::Windows::Forms::Button^  btReset;
	private: System::Windows::Forms::PictureBox^  pictureBox1;

	private:
		/// <summary>
		/// ����������������
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����֧������ķ��� - ��Ҫ
		/// ʹ�ô���༭���޸Ĵ˷��������ݡ�
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Regist::typeid));
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->tbName = (gcnew System::Windows::Forms::TextBox());
			this->tbPwd = (gcnew System::Windows::Forms::TextBox());
			this->tbTrueName = (gcnew System::Windows::Forms::TextBox());
			this->tbAddress = (gcnew System::Windows::Forms::TextBox());
			this->tbTel = (gcnew System::Windows::Forms::TextBox());
			this->cbType = (gcnew System::Windows::Forms::ComboBox());
			this->btOk = (gcnew System::Windows::Forms::Button());
			this->btReset = (gcnew System::Windows::Forms::Button());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// label2
			// 
			resources->ApplyResources(this->label2, L"label2");
			this->label2->Name = L"label2";
			this->label2->Click += gcnew System::EventHandler(this, &Regist::label2_Click);
			// 
			// label3
			// 
			resources->ApplyResources(this->label3, L"label3");
			this->label3->Name = L"label3";
			// 
			// label4
			// 
			resources->ApplyResources(this->label4, L"label4");
			this->label4->Name = L"label4";
			// 
			// label5
			// 
			resources->ApplyResources(this->label5, L"label5");
			this->label5->Name = L"label5";
			// 
			// label6
			// 
			resources->ApplyResources(this->label6, L"label6");
			this->label6->Name = L"label6";
			// 
			// label7
			// 
			resources->ApplyResources(this->label7, L"label7");
			this->label7->Name = L"label7";
			// 
			// tbName
			// 
			resources->ApplyResources(this->tbName, L"tbName");
			this->tbName->Name = L"tbName";
			// 
			// tbPwd
			// 
			resources->ApplyResources(this->tbPwd, L"tbPwd");
			this->tbPwd->Name = L"tbPwd";
			// 
			// tbTrueName
			// 
			resources->ApplyResources(this->tbTrueName, L"tbTrueName");
			this->tbTrueName->Name = L"tbTrueName";
			// 
			// tbAddress
			// 
			resources->ApplyResources(this->tbAddress, L"tbAddress");
			this->tbAddress->Name = L"tbAddress";
			// 
			// tbTel
			// 
			resources->ApplyResources(this->tbTel, L"tbTel");
			this->tbTel->Name = L"tbTel";
			// 
			// cbType
			// 
			this->cbType->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->cbType->FormattingEnabled = true;
			this->cbType->Items->AddRange(gcnew cli::array< System::Object^  >(2) {resources->GetString(L"cbType.Items"), resources->GetString(L"cbType.Items1")});
			resources->ApplyResources(this->cbType, L"cbType");
			this->cbType->Name = L"cbType";
			// 
			// btOk
			// 
			resources->ApplyResources(this->btOk, L"btOk");
			this->btOk->Name = L"btOk";
			this->btOk->UseVisualStyleBackColor = true;
			this->btOk->Click += gcnew System::EventHandler(this, &Regist::btOk_Click);
			// 
			// btReset
			// 
			resources->ApplyResources(this->btReset, L"btReset");
			this->btReset->Name = L"btReset";
			this->btReset->UseVisualStyleBackColor = true;
			this->btReset->Click += gcnew System::EventHandler(this, &Regist::btReset_Click);
			// 
			// pictureBox1
			// 
			resources->ApplyResources(this->pictureBox1, L"pictureBox1");
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->TabStop = false;
			// 
			// Regist
			// 
			resources->ApplyResources(this, L"$this");
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->btReset);
			this->Controls->Add(this->btOk);
			this->Controls->Add(this->cbType);
			this->Controls->Add(this->tbTel);
			this->Controls->Add(this->tbAddress);
			this->Controls->Add(this->tbTrueName);
			this->Controls->Add(this->tbPwd);
			this->Controls->Add(this->tbName);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->MinimizeBox = false;
			this->Name = L"Regist";
			this->Load += gcnew System::EventHandler(this, &Regist::Regist_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btOk_Click(System::Object^  sender, System::EventArgs^  e) 
	{
		

		if(this->tbName->Text->Trim() == "")
		{
			MessageBox::Show( "�û�������Ϊ��.", "�û����������",
				MessageBoxButtons::OK, MessageBoxIcon::Exclamation );

			return;
		}

		String^ name = this->tbName->Text->Trim();

		if(this->tbPwd->Text->Trim() == "")
		{
			MessageBox::Show( "���벻��Ϊ��.", "�����������",
				MessageBoxButtons::OK, MessageBoxIcon::Exclamation );

			return;
		}

		String^ pwd = this->tbPwd->Text->Trim();

		if(this->tbTrueName->Text->Trim() == "")
		{
			MessageBox::Show( "��ʵ��������Ϊ��.", "��ʵ�����������",
				MessageBoxButtons::OK, MessageBoxIcon::Exclamation );

			return;
		}

		String^ trueName = this->tbTrueName->Text->Trim();

		if(this->tbAddress->Text->Trim() == "")
		{
			MessageBox::Show( "��ַ����Ϊ��.", "��ַ�������",
				MessageBoxButtons::OK, MessageBoxIcon::Exclamation );

			return;
		}

		String^ address = this->tbAddress->Text->Trim();

		if(this->tbTel->Text->Trim() == "")
		{
			MessageBox::Show( "�绰����Ϊ��.", "�绰�������",
				MessageBoxButtons::OK, MessageBoxIcon::Exclamation );

			return;
		}

		String^ tel = this->tbTel->Text->Trim();

		if(this->cbType->SelectedIndex <0)
		{
			MessageBox::Show( "�û����Ͳ���Ϊ��.", "�û������������",
				MessageBoxButtons::OK, MessageBoxIcon::Exclamation );

			return;
		}

		int userType = this->cbType->SelectedIndex;

		//ע���û�
		String^ sql = "insert into users (username,password,truename,address,telephone,usertype) values('"+name+"','"+pwd+"','"+trueName+"','"+address+"','"+tel+"','"+userType+"')";

		//sprintf_s(sql,"insert into users (username,password,truename,address,telephone,usertype) values('%s','%s','%s','%s','%s','%s')",name,pwd,trueName,address,tel,userType);

		DBHelper *dbHelper = new DBHelper();
		if (dbHelper->connect())
		{
			//���ȼ�鵱ǰ�û����Ƿ��Ѿ���ע����
			String^ isExistUser = "select * from users where username='"+name+"'";

			MYSQL_RES* res = dbHelper->executeQuery(isExistUser);

			long rowcount = mysql_num_rows(res);
			if(rowcount > 0)
			{
				MessageBox::Show( "���û����Ѵ���,����������.", "�û�������",
					MessageBoxButtons::OK, MessageBoxIcon::Exclamation );
			}
			else
			{
				if(dbHelper->executeNonQuery(sql))
				{
					MessageBox::Show( "ע��ɹ�,��رձ����ڽ��е�½.", "�ɹ�",
						MessageBoxButtons::OK, MessageBoxIcon::Exclamation );
				}
				else
				{
					MessageBox::Show( "�������ݿ�ʧ��,������������.", "�������ݿ�ʧ��",
						MessageBoxButtons::OK, MessageBoxIcon::Exclamation );
				}
			}
			
		}
		else
		{	
			MessageBox::Show( "���ݿ�����ʧ��,������������.", "���ݿ�����ʧ��",
				MessageBoxButtons::OK, MessageBoxIcon::Exclamation );
		
		}
		delete dbHelper;
	}
private: System::Void btReset_Click(System::Object^  sender, System::EventArgs^  e) 
	{
		this->tbName->Text = "";
		this->tbPwd->Text = "";
		this->tbTrueName->Text = "";
		this->tbAddress->Text = "";
		this->tbTel->Text = "";		
	}
private: System::Void Regist_Load(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label2_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}
