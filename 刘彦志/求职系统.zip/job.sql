﻿# Host: localhost  (Version: 5.5.28)
# Date: 2015-01-04 22:56:40
# Generator: MySQL-Front 5.3  (Build 4.13)

/*!40101 SET NAMES utf8 */;

#
# Source for table "job"
#

DROP TABLE IF EXISTS `job`;
CREATE TABLE `job` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `jobName` varchar(50) DEFAULT NULL,
  `companyId` varchar(50) DEFAULT NULL,
  `workAddress` varchar(255) DEFAULT NULL,
  `jobDescription` varchar(200) DEFAULT NULL,
  `jobRequirement` varchar(1000) DEFAULT NULL,
  `salary` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

#
# Data for table "job"
#

INSERT INTO `job` VALUES (1,'工作1','公司1','工作地点1','工作描述1','工作要求1',10000),(2,'工作2','公司2','工作地点2','工作描述2','工作要求2',10001),(3,'工作3','公司3','工作地点3','工作描述3','工作要求3',10002),(4,'工作4','公司4','工作地点4','工作描述4','工作要求4',10003);

#
# Source for table "userjob"
#

DROP TABLE IF EXISTS `userjob`;
CREATE TABLE `userjob` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `jobid` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

#
# Data for table "userjob"
#

INSERT INTO `userjob` VALUES (1,12,1),(2,12,2),(3,12,3),(4,13,3);

#
# Source for table "users"
#

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `truename` varchar(255) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `usertype` int(2) DEFAULT NULL,
  `info1` varchar(500) DEFAULT NULL,
  `info2` varchar(500) DEFAULT NULL,
  `info3` varchar(500) DEFAULT NULL,
  `score` int(11) DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

#
# Data for table "users"
#

INSERT INTO `users` VALUES (12,'求职者1','123','求职者1','中国北京','138881241',0,'精通c语言,掌握c++,常用c#','自我介绍1','获奖经历11',0),(13,'求职者2','123','求职者2','中国上海','138881242',0,'精通c语言,掌握c++,常用c#','自我介绍1','获奖经历11',0),(14,'求职者3','123','求职者3','中国广州','138881243',0,'精通c语言,掌握c++,常用c#','自我介绍1','获奖经历11',0),(15,'求职者4','123','求职者4','中国深圳','138881244',0,'精通c语言,掌握c++,常用c#','自我介绍1','获奖经历11',0),(16,'公司1','123','公司1','中国北京','138881251',1,'公司介绍111','职位需求222','发展定位333',0),(17,'公司2','123','公司2','中国上海','138881252',1,NULL,NULL,NULL,0),(18,'公司3','123','公司3','中国广州','138881253',1,NULL,NULL,NULL,0),(19,'公司4','123','公司4','中国深圳','138881254',1,NULL,NULL,NULL,2),(20,'管理员','123','超级管理员','中国北京','138881245',2,NULL,NULL,NULL,0);
